// // Define card data
// const cardData = [
//     { title: "Card 1", likes: 0 },
//     { title: "Card 2", likes: 0 },
//     { title: "Card 3", likes: 0 },
//     { title: "Card 4", likes: 0 },
//     { title: "Card 5", likes: 0 },
//     { title: "Card 6", likes: 0 },
//     { title: "Card 7", likes: 0 },
//     { title: "Card 8", likes: 0 },
//   ];


//   // Get elements
//   const cardContainer = document.getElementById("card-container");
//   const loadMoreBtn = document.getElementById("load-more-btn");


//   // Define variables
//   let loadedCardCount = 0;
//   const CARDS_PER_LOAD = 4;


//   // Load initial cards
//   loadCards();


//   // Load more cards on click
//   loadMoreBtn.addEventListener("click", loadCards);


//   // Function to load cards
//   function loadCards() {
//     // Calculate index range of cards to load
//     const startIndex = loadedCardCount;
//     const endIndex = loadedCardCount + CARDS_PER_LOAD;


//     // Check if there are still cards to load
//     if (startIndex >= cardData.length) {
//       // Hide load more button if all cards have been loaded
//       loadMoreBtn.style.display = "none";
//       return;
//     }


//     // Loop through card data and create HTML for new cards
//     for (let i = startIndex; i < endIndex && i < cardData.length; i++) {
//       const card = cardData[i];
//       const cardHtml = `
//         <div class="card">
//           <h3>${card.title}</h3>
//           <p>Likes: <span class="likes">${card.likes}</span></p>
//           <i class="heart"></i>
//         </div>
//       `;
//       cardContainer.insertAdjacentHTML("beforeend", cardHtml);
//     }


//     // Increment loaded card count
//     loadedCardCount += CARDS_PER_LOAD;
//   }


//   // Add event listener to card container to handle like clicks
//   cardContainer.addEventListener("click", (event) => {
//     const heart = event.target.closest(".heart");
//     if (heart) {
//       const card = heart.closest(".card");
//       const likes = card.querySelector(".likes");
//       const isActive = heart.classList.contains("active");


//       // Update like count and heart icon
//       if (isActive) {
//         cardData[loadedCardCount - CARDS_PER_LOAD + Array.from(cardContainer.children).indexOf(card)].likes--;
//         heart.classList.remove("active");
//         likes.innerText--;
//       } else {
//         cardData[loadedCardCount - CARDS_PER_LOAD + Array.from(cardContainer.children).indexOf(card)].likes++;
//         heart.classList.add("active");
//         likes.innerText++;
//       }
//     }
//   });


// Get elements
const cardContainer = document.getElementById("card-container");
const loadMoreBtn = document.getElementById("load-more-btn");


// Define variables
let loadedCardCount = 0;
const CARDS_PER_LOAD = 4;
let cardData = [];


// Load initial cards
loadCards();


// Load more cards on click
loadMoreBtn.addEventListener("click", loadCards);


// Function to load cards
function loadCards() {
    // Calculate index range of cards to load
    const startIndex = loadedCardCount;
    const endIndex = loadedCardCount + CARDS_PER_LOAD;

    // Check if there are still cards to load
    if (startIndex >= cardData.length && cardData.length != 0) {

        // Hide load more button if all cards have been loaded
        loadMoreBtn.style.display = "none";
        return;
    }


    // Loop through card data and create HTML for new cards
    for (let i = startIndex; i < endIndex && i < cardData.length; i++) {
        const card = cardData[i];
        const date = new Date(card.date);
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        const formattedDate = date.toLocaleDateString('en-US', options);
        const cardHtml = `
      <div class="card">
      <div class="header">
      <div class="profile-pic-wrapper"><img  class="profile-pic" src="${card.profile_image}" alt="${card.name}"></div>
      <div class="header-wrapper">
      <div class="name-date-wrapper"><p class="card-name">${card.name}</p>
      <div class="card-date">${formattedDate}</div>
      </div>
      <div class="icon">${card.source_type === 'facebook' ?
                `<img src="../icons/facebook.svg"/>` : card.source_type === 'instagram'
                 && ` <img src="../icons/instagram-logo.svg"/>`}
        </div>
      </div>
      </div>
        <img class="post" src="${card.image}" alt="${card.caption}">
        <div class="description">${card.caption}</div>
        <div class="">
        <hr/>
        <div class="likes"><img src="../icons/heart.svg"><span>${card.likes}</span></div>
        </div>
      </div>
    `;
        cardContainer.insertAdjacentHTML("beforeend", cardHtml);
    }


    // Increment loaded card count
    loadedCardCount += CARDS_PER_LOAD;
}


// Add event listener to card container to handle like clicks
cardContainer.addEventListener("click", (event) => {
    const heart = event.target.closest(".heart");
    if (heart) {
        const card = heart.closest(".card");
        const likes = card.querySelector(".likes");
        const isActive = heart.classList.contains("active");


        // Update like count and heart icon
        if (isActive) {
            cardData[loadedCardCount - CARDS_PER_LOAD + Array.from(cardContainer.children).indexOf(card)].likes--;
            heart.classList.remove("active");
            likes.innerText--;
        } else {
            cardData[loadedCardCount - CARDS_PER_LOAD + Array.from(cardContainer.children).indexOf(card)].likes++;
            heart.classList.add("active");
            likes.innerText++;
        }
    }
});


// Get the radio buttons and cards
const lightRadio = document.querySelector('input[value="lightTheme"]');
const darkRadio = document.querySelector('input[value="darkTheme"]');
const cards = document.querySelectorAll('.card');


const card = document.querySelector('.card-container');


// Add event listener to the radio buttons
lightRadio.addEventListener('change', () => {
    // Change the card styles to the light theme
    cards.forEach(card => {
      card.style.backgroundColor = 'white';
      card.style.color = 'black';
    });
  });
 
  darkRadio.addEventListener('change', () => {
   // Change the card styles to the dark theme
    cards.forEach(card => {
      card.style.backgroundColor = 'black';
      card.style.color = 'white';
    });
  });


// Fetch card data from JSON file
fetch("data.json")
    .then((response) => response.json())
    .then((data) => {
        cardData = data;
        loadCards();
    })
    .catch((error) => console.error(error));

